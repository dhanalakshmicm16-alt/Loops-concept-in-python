import os
import sys
from pathlib import Path

# Ensure project root is on sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quiz_project.settings')
import django
django.setup()

from quizzes.models import Quiz, Question, Choice

sample_data = [
    {
        'title': 'Exam Prep - Mathematics',
        'description': 'Important topics for competitive exams',
        'time_limit': 20,
        'questions': [
            {'text': 'What is the value of 2^5?', 'choices': [('32', True), ('16', False), ('8', False)]},
            {'text': 'Solve for x: 2x + 3 = 11', 'choices': [('4', True), ('3', False), ('5', False)]},
            {'text': 'If a triangle has angles 30 and 60, the third angle is?', 'choices': [('90', True), ('120', False), ('45', False)]},
        ]
    },
    {
        'title': 'Exam Prep - English',
        'description': 'Grammar and vocabulary questions for exams',
        'time_limit': 15,
        'questions': [
            {'text': 'Choose the correct sentence:', 'choices': [('She don\'t like it.', False), ('She doesn\'t like it.', True), ('She not likes it.', False)]},
            {'text': 'Synonym of "rapid"', 'choices': [('slow', False), ('quick', True), ('lazy', False)]},
            {'text': 'Fill the blank: He is ____ engineer.', 'choices': [('a', True), ('an', False), ('the', False)]},
        ]
    },
    {
        'title': 'Exam Prep - Science',
        'description': 'Basic science concepts often seen in exams',
        'time_limit': 18,
        'questions': [
            {'text': 'Which is a renewable energy source?', 'choices': [('Coal', False), ('Solar', True), ('Petrol', False)]},
            {'text': 'The chemical symbol for Sodium is?', 'choices': [('Na', True), ('S', False), ('So', False)]},
            {'text': 'Force is measured in?', 'choices': [('Watts', False), ('Newtons', True), ('Joules', False)]},
        ]
    }
]

created = 0
for quiz_data in sample_data:
    title = quiz_data['title']
    if Quiz.objects.filter(title=title).exists():
        print(f"Quiz '{title}' already exists, skipping.")
        continue
    q = Quiz.objects.create(title=title, description=quiz_data['description'], time_limit=quiz_data['time_limit'])
    for ques in quiz_data['questions']:
        que = Question.objects.create(quiz=q, text=ques['text'])
        for choice_text, is_correct in ques['choices']:
            Choice.objects.create(question=que, text=choice_text, is_correct=is_correct)
    print(f"Created quiz '{title}' (id={q.id})")
    created += 1

print(f"Finished. Created {created} new exam quizzes.")
