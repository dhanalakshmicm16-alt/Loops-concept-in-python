import os
import sys
import json
import csv
from pathlib import Path

# Ensure project root is on sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quiz_project.settings')
import django
django.setup()

from quizzes.models import Quiz

out_dir = BASE_DIR / 'data'
out_dir.mkdir(exist_ok=True)

# Build JSON structure
quizzes = []
for q in Quiz.objects.all():
    quiz_obj = {
        'id': q.id,
        'title': q.title,
        'description': q.description,
        'time_limit': q.time_limit,
        'questions': []
    }
    for ques in q.questions.all():
        ques_obj = {'id': ques.id, 'text': ques.text, 'choices': []}
        for c in ques.choices.all():
            ques_obj['choices'].append({'id': c.id, 'text': c.text, 'is_correct': c.is_correct})
        quiz_obj['questions'].append(ques_obj)
    quizzes.append(quiz_obj)

json_path = out_dir / 'quizzes_export.json'
with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(quizzes, f, ensure_ascii=False, indent=2)

# Write CSV with one row per choice
csv_path = out_dir / 'quizzes_export.csv'
with open(csv_path, 'w', encoding='utf-8', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['quiz_id', 'quiz_title', 'question_id', 'question_text', 'choice_id', 'choice_text', 'is_correct'])
    for quiz in quizzes:
        for ques in quiz['questions']:
            for choice in ques['choices']:
                writer.writerow([quiz['id'], quiz['title'], ques['id'], ques['text'], choice['id'], choice['text'], choice['is_correct']])

print(f"Exported {len(quizzes)} quizzes to:\n - {json_path}\n - {csv_path}")
