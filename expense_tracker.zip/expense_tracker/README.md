# Django Expense Tracker

Simple Django Expense Tracker project for students and mini-projects.

Setup

1. Create virtualenv and activate:
   py -3 -m venv venv; .\venv\Scripts\Activate.ps1
2. Install Django:
   pip install django
3. Run migrations:
   python manage.py migrate
4. Run server:
   python manage.py runserver

Add expense via the form on the homepage.
