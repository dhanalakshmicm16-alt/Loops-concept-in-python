import os
import sys
from pathlib import Path

# Ensure project root is on sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quiz_project.settings')
import django
django.setup()

from quizzes.models import Quiz, Question, Choice

if not Quiz.objects.filter(title='Sample Quiz').exists():
    q = Quiz.objects.create(title='Sample Quiz', description='Demo quiz', time_limit=5)
    que = Question.objects.create(quiz=q, text='What is 2+2?')
    Choice.objects.create(question=que, text='3', is_correct=False)
    Choice.objects.create(question=que, text='4', is_correct=True)
    print('Created quiz', q.id)
else:
    print('Sample Quiz already exists')
