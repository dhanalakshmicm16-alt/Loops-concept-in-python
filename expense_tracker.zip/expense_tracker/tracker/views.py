from django.shortcuts import render, redirect
from .models import Expense
from django.db.models import Sum


def index(request):
    if request.method == "POST":
        date = request.POST['date']
        amount = request.POST['amount']
        desc = request.POST['description']
        Expense.objects.create(date=date, amount=amount, description=desc)
        return redirect('/')

    daily = Expense.objects.values('date').annotate(total=Sum('amount'))
    monthly = Expense.objects.extra(
        select={'month': "strftime('%%Y-%%m', date)"}
    ).values('month').annotate(total=Sum('amount'))

    return render(request, 'index.html', {
        'daily': daily,
        'monthly': monthly
    })
