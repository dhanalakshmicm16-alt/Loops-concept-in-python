from django.apps import AppConfig


class AdminpanelConfig(AppConfig):
    name = 'adminpanel'
